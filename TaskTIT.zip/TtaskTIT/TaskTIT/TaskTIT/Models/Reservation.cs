﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TaskTIT.Models
{
    public class Reservation : IValidatableObject
    {
        public int ID { set; get; }
        public DateTime From { set; get; }
        public DateTime To { set; get; }

        [ForeignKey("Room")] public int Room_id { set; get; }

        public Room Room { set; get; }

        [ForeignKey("RoomType")] public int RoomType_id { set; get; }

        public virtual RoomType RoomType { set; get; }
        public double Price { set; get; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (From > To)
                yield return new ValidationResult
                    ("The Duration Is Not Valid Please Choose Dates Wisly", new[] {"To"});
        }

        public class ReservationViwModel
        {
            [Required] public DateTime From { set; get; }

            [Required] public DateTime To { set; get; }

            [Required] public int Room { set; get; }

            public int RoomType { set; get; }
        }

        public class ReservationViw
        {
            public int ID { set; get; }
            public DateTime From { set; get; }
            public DateTime To { set; get; }
            public int NumberOfDays { set; get; }
            public double Price { set; get; }
            public Room Room { set; get; }
            public RoomType RoomType { set; get; }
        }
    }
}