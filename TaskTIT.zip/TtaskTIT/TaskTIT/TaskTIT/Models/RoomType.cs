﻿using System.ComponentModel.DataAnnotations;

namespace TaskTIT.Models
{
    public class RoomType
    {
        public int ID { set; get; }

        [Required] public string type { set; get; }

        [Required] public double price { set; get; }
    }
}