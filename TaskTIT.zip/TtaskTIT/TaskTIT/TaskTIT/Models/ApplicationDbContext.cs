﻿using System.Data.Entity;
using TaskTIT.Models.Initializer;

namespace TaskTIT.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext() : base("DefaultConnection")
        {
            Database.SetInitializer(new HotelDataInitializer());
        }

        public DbSet<Room> Rooms { set; get; }
        public DbSet<RoomType> RoomTypes { set; get; }
        public DbSet<Reservation> Reservations { set; get; }
    }
}