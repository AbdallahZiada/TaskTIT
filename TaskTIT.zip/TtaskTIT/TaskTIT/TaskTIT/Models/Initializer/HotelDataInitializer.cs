﻿using System.Collections.Generic;
using System.Data.Entity;

namespace TaskTIT.Models.Initializer
{
    public class HotelDataInitializer : CreateDatabaseIfNotExists<ApplicationDbContext>
    {
        protected override void Seed(ApplicationDbContext context)
        {
            var roomtype1 = new RoomType {type = "Superior Room", price = 100};
            var roomtype2 = new RoomType {type = "Suite", price = 200};
            var roomtype3 = new RoomType {type = "Family Room", price = 300};
            var roomtype4 = new RoomType {type = "Villas", price = 400};

            var roomTypes = new List<RoomType>
                {roomtype1, roomtype2, roomtype3, roomtype4};

            var rooms = new List<Room>
            {
                new Room {RoomNumber = 1, RoomType = roomtype1},
                new Room {RoomNumber = 2, RoomType = roomtype1},
                new Room {RoomNumber = 3, RoomType = roomtype1},
                new Room {RoomNumber = 4, RoomType = roomtype2},
                new Room {RoomNumber = 5, RoomType = roomtype2},
                new Room {RoomNumber = 6, RoomType = roomtype2},
                new Room {RoomNumber = 7, RoomType = roomtype3},
                new Room {RoomNumber = 8, RoomType = roomtype3},
                new Room {RoomNumber = 9, RoomType = roomtype4},
                new Room {RoomNumber = 10, RoomType = roomtype4}
            };

            context.RoomTypes.AddRange(roomTypes);

            context.Rooms.AddRange(rooms);

            base.Seed(context);
        }
    }
}