﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TaskTIT.Models
{
    public class Room
    {
        public int ID { get; set; }

        [Required] public int RoomNumber { get; set; }

        [ForeignKey("RoomType")] public int? RoomType_id { set; get; }

        public RoomType RoomType { set; get; }
    }
}