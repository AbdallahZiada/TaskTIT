﻿using Microsoft.Owin;
using Owin;
using TaskTIT;

[assembly: OwinStartup(typeof(Startup))]

namespace TaskTIT
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.MapSignalR();
        }
    }
}