﻿var hub;
var rooms = [];
$(function() {
    $("#datetimepickerfrom").datetimepicker();
    $("#datetimepickerto").datetimepicker();

    $("#Room").prop("disabled", true);
    $("#EditMode").hide();
    var EditMode = false;

    hub = $.connection.reservationHub;

    hub.client.broadCastRooms = function(data) {
        $("#Room").empty();
        $("#Room").prop("disabled", false);
        $.each(data,
            function(key, value) {
                rooms.push(value);
                $("#Room").append('<option value="' + value.RoomNumber + '"> Room ' + value.RoomNumber + "</option>");
            });
    };
    hub.client.editingOnReserviation = function(data) {
        $("#RoomType option[selected=selected]").removeAttr("selected");
        $("#RoomType").val('"' + data.RoomType.ID + '"');
        $("#RoomType option[value=" + data.RoomType.ID + "]").attr("selected", "selected");
        $("#RoomType").trigger("change");
        $("#Room").prop("disabled", false);
        $("#from").val(data.From);
        $("#to").val(data.To);
    };

    $.connection.hub.start().done(function() {
        $("#RoomType").change(function() {
            hub.server.getRooms($(this).val());
        });
    });
});

function ChangeEditMode(Rid) {
    if (Rid <= 0) {
        EditMode = false;
        $("#ReservForm").attr("action", "/Reservations/Create");
        $("#ReserveMode").show();
        $("#EditMode").hide();
        $("#RoomType option[value=0]").attr("selected", "selected");
        $("#RoomType").trigger("change");
        $("#Room").prop("disabled", true);
        $("#from").val("");
        $("#to").val("");
    } else {
        EditMode = true;
        $("#ReservForm").attr("action", "/Reservations/Edit");
        $("#ReserveMode").hide();
        $("#EditMode").show();
        hub.invoke("editReservation", Rid, EditMode);
    }
}