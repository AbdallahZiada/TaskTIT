﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNet.SignalR;
using TaskTIT.Models;

namespace TaskTIT.Hubs
{
    public class ReservationHub : Hub
    {
        public static Reservation Reserv = new Reservation();
        private static bool Editing;
        private static Room Editingroom;
        private readonly ApplicationDbContext db = new ApplicationDbContext();
        private List<Room> rooms = new List<Room>();

        public void GetRooms(int RoomTypeID)
        {
            if (db.RoomTypes.Any(r => r.ID == RoomTypeID))
                rooms = db.Rooms.Where(r =>
                    r.RoomType_id == RoomTypeID && db.Reservations.Where(x => x.Room_id == r.ID).Count() == 0).ToList();
            if (Editing)
                rooms.Add(db.Rooms.Where(r => r.RoomType_id == RoomTypeID && r.ID == Editingroom.ID).FirstOrDefault());
            Clients.Caller.BroadCastRooms(rooms);
        }

        public void EditReservation(int ReservationID, bool EditMode)
        {
            if (EditMode)
            {
                Editing = EditMode;
                if (db.Reservations.Any(r => r.ID == ReservationID))
                {
                    Reserv = db.Reservations.Where(t => t.ID == ReservationID).FirstOrDefault();
                    Reserv.Room = db.Rooms.Where(f => f.ID == Reserv.Room_id).FirstOrDefault();
                    Editingroom = Reserv.Room;
                }
            }

            Clients.Caller.EditingOnReserviation(Reserv);
        }
    }
}