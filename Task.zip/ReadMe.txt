the database is made with code first approach
also no need to make the migrations stuff i made an initializer for it

just run the project and it may take some time in first and then it will work just fine
--------------
and please if you have any comments notify me

abdallah_ziada@hotmail.com