﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TaskTIT.Models;
using static TaskTIT.Models.Reservation;
using System.Diagnostics;

namespace TaskTIT.Controllers
{
    public class ReservationsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // POST: Reservations/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "From,To,Room,RoomType")] ReservationViwModel reservationvm)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var room = db.Rooms.Where(x => x.ID == reservationvm.Room).First();
                    var roomt = db.RoomTypes.Where(x => x.ID == reservationvm.RoomType).First();
                    Reservation reservation = new Reservation();
                    reservation.From = reservationvm.From;
                    reservation.To = reservationvm.To;
                    reservation.Room_id = room.ID;
                    reservation.Price= ((int)(reservationvm.To - reservationvm.From).TotalDays)*roomt.price;
                    reservation.RoomType_id = roomt.ID;
                    if (ModelState.IsValid && (db.Reservations.Where(x => x.Room_id == room.ID).Count() == 0))
                    {
                        db.Reservations.Add(reservation);
                        await db.SaveChangesAsync();   
                    }
                }
                catch
                {
                    foreach (var validationResults in db.GetValidationErrors())
                    {
                        foreach (var error in validationResults.ValidationErrors)
                        {
                            ModelState.AddModelError(string.Empty, error.ErrorMessage);
                        }
                    }
                }
            }
            return RedirectToAction("Index","Home");
        }

        // POST: Reservations/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "From,To,Room,RoomType")] ReservationViwModel reservationvm)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var room = db.Rooms.Where(x => x.ID == reservationvm.Room).First();
                    var roomt = db.RoomTypes.Where(x => x.ID == reservationvm.RoomType).First();
                    var updateReserv = db.Reservations.Single(x => x.ID == TaskTIT.Hubs.ReservationHub.Reserv.ID);
                    updateReserv.From = reservationvm.From;
                    updateReserv.To = reservationvm.To;
                    updateReserv.Room_id = room.ID;
                    updateReserv.Price = ((int)(reservationvm.To - reservationvm.From).TotalDays) * roomt.price;
                    updateReserv.RoomType_id = roomt.ID;
                    if (ModelState.IsValid && (db.Reservations.Where(x => x.Room_id == room.ID).Count() == 0))
                    {
                        await db.SaveChangesAsync();
                    }
                }
                catch
                {
                    foreach (var validationResults in db.GetValidationErrors())
                    {
                        foreach (var error in validationResults.ValidationErrors)
                        {
                            ModelState.AddModelError(string.Empty, error.ErrorMessage);
                        }
                    }
                }
            }
            return RedirectToAction("Index", "Home");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
