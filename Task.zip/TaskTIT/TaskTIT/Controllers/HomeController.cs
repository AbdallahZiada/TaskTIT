﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using TaskTIT.Models;
using static TaskTIT.Models.Reservation;

namespace TaskTIT.Controllers
{
    public class HomeController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        public ActionResult Index()
        {
            TempData["RoomType"] = db.RoomTypes;
            var Reservations = db.Reservations.ToList();
            List<ReservationViw> rvm = new List<ReservationViw>();
            foreach (var item in Reservations)
            {
                var room = db.Rooms.Where(r => r.ID == item.Room_id).FirstOrDefault();
                room.RoomType =db.RoomTypes.Where(b=>b.ID==room.RoomType_id).FirstOrDefault();
                
                var days = (int)(item.To - item.From).TotalDays;
                var rv = new ReservationViw();
                rv.ID = item.ID;
                rv.From = item.From;
                rv.To = item.To;
                rv.NumberOfDays = days;
                rv.Price = item.Price;
                rv.Room = room;
                rv.RoomType = room.RoomType;
                rvm.Add(rv);
            }
            
            return View(rvm);
        }
        public async Task<ActionResult> Delete(int id)
        {
            Reservation reservation = await db.Reservations.FindAsync(id);
            db.Reservations.Remove(reservation);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
    }
}