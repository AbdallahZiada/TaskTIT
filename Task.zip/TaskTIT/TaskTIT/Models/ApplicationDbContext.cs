﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using TaskTIT.Models.Initializer;

namespace TaskTIT.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext():base("DefaultConnection")
        {
            Database.SetInitializer(new HotelDataInitializer());
        }
        public DbSet<Room> Rooms { set; get; }
        public DbSet<RoomType> RoomTypes { set; get; }
        public DbSet<Reservation> Reservations { set; get; }

    }
}