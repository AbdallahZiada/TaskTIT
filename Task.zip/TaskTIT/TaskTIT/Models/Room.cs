﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace TaskTIT.Models
{
    public class Room
    {
        public int ID { get; set; }
        [Required]
        public int RoomNumber { get; set; }
        [ForeignKey("RoomType")]
        public int? RoomType_id { set; get; }
        public RoomType RoomType { set; get; }
    }
}