﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace TaskTIT.Models
{
    public class RoomType
    {
        public int ID { set; get; }
        [Required]
        public string type { set; get; }
        [Required]
        public double price { set; get; }
    }
}